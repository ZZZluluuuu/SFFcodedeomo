function [outputArg1] = Fun_fitdepthsurface(depthimage,simpara)
result1=depthimage;
[rownum,columnnum]=size(depthimage);
indexx=1:rownum;
indexx=indexx';
for c=1:columnnum 
     RData=result1(:,c);  
       RDataNew=smooth(RData(indexx),simpara,'moving');
       result1(:,c)=RDataNew(indexx)';
end
indexx=1:columnnum;
indexx=indexx';
for c=1:rownum 
     RData=result1(c,:)';
     RDataNew=smooth(RData(indexx)',simpara,'moving');
       result1(c,:)=RDataNew(indexx)';
   end
outputArg1 =result1;
end