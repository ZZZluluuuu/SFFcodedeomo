function Flag = fun_Classify(Ini_FV,net)
A_FV=UP_scale_volume(Ini_FV);
FV_size = size(A_FV);
z_data = reshape(A_FV, FV_size(1)*FV_size(2), FV_size(3), []);
z_data = permute(z_data, [3, 2, 1]);
z_data_re = imresize(z_data, [1, 165], 'Method', 'bilinear');
z_data_re = reshape(z_data_re, [1, 165, 1, numel(z_data_re)/(1*165*1)]);
pre = classify(net, z_data_re);
Flag = double(reshape(pre, [FV_size(1), FV_size(2)]));
Flag(Flag == 2) = 0;
end