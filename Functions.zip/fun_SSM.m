function qiwang=fun_SSM(A)
%Calculate the SSM
[m,n]=size(A);
Result=zeros(m-2,n-2);
for i=2:m-1
    for j=2:n-1
        Result(i-1,j-1)=(A(i+1,j)-2*A(i,j)+A(i-1,j)).^2+...
            2*(A(i+1,j+1)-A(i,j+1)-A(i+1,j)+A(i,j)).^2+...
            (A(i,j+1)-2*A(i,j)+A(i,j-1)).^2;
    end
end
qiwang=mean(Result(:));
end