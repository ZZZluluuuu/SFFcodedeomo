function Result=fun_GLV_Local(I,q)
% Gray-level variance (GLV)
[m,n]=size(I);
m1=floor(m/q);
n1=floor(n/q);
Result=zeros(m1,n1);
Ls2=(q-1)/2;
I = padarray(I,[Ls2,Ls2],'symmetric');
for i=1:m1
    for j=1:n1
        A=I((i-1)*q+1:i*q,(j-1)*q+1:j*q);
        A1=(A-mean(mean(A))).^2;
        Result(i,j)=sum(sum(A1));         
    end
end
end




