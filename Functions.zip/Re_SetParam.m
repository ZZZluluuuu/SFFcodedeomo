function [xSteps,ySteps,zSteps,stepDistance,pixelThan1,x_pin,y_pin] = Re_SetParam(RootPath)
% %     RootPath = GetRootPath();
% %     RootPath = [RootPath,'\'];
%     feature('DefaultCharacterSet', 'UTF8');
%     FileName = [RootPath,'Param.txt'];
%     data = importdata(FileName);
%     mdata = data.textdata;
%     Rows = str2double(mdata{8}(9:end));
%     Cols = str2double(mdata{10}(9:end));
%     SeqNum = str2double(mdata{12}(8:end));
%     SeqStep = str2double(mdata{13}(8:end-3));
%     pixelratio = str2double(mdata{5}(5:end));

%% Parameters are read automatically
inffilename='';
nInfFileIsExist=uint8(0);
if exist([RootPath,'\','Param.txt'])>0
inffilename=[RootPath,'\','Param.txt'];
nInfFileIsExist=1;
end
if exist([RootPath,'\','采集参数.txt'])>0
inffilename=[RootPath,'\','采集参数.txt'];
nInfFileIsExist=2;
end
if nInfFileIsExist==0
return;
end
Para=[];

xSteps=uint16(0); 
ySteps=uint16(0);
zSteps=uint16(0);
stepDistance=0;
x_pin=double(0);
y_pin=double(0); 
pixelThan1=0;um
file_t=fopen(inffilename,'r');
strcontent=textscan(file_t, '%s');
if nInfFileIsExist==1
index=[6 7 9 10 11 12 14 15 17 18 20 21 22 23];
for n=index
curstr=cell2mat(strcontent{1}(n));
numtem = str2double(regexp(curstr,'-?\d+(\.\d+)?','match'));
if uint8(n)==10
numtem=numtem/100;
end
Para=[Para,numtem];
end
xSteps=uint16(Para(5)); 
ySteps=uint16(Para(7));
zSteps=uint16(Para(9));
stepDistance=Para(10);
x_pin=double(Para(2)*Para(4));
y_pin=double(Para(3)*Para(4));

pixelThan1=Para(1);
end
if nInfFileIsExist==2
index=[4 6 8 10 11 12 14 15 16 18 19 21 22 23 24];
for n=index
curstr=cell2mat(strcontent{1}(n));
numtem = str2double(regexp(curstr,'-?\d+(\.\d+)?','match'));
Para=[Para,numtem];
end
xSteps=uint16(Para(12))+1; 
ySteps=uint16(Para(13))+1;
zSteps=uint16(Para(14))+1;
stepDistance=Para(9);
x_pin=double(Para(10));
y_pin=double(Para(11)); 
pixelThan1=Para(1);
end
fclose(file_t);




end