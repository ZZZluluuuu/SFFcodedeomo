function vol_scaled = scale_volume(vol)
%NORMALIZE_VOLUME Change scaling of the focus volume to be in the
%target_range.
%   INPUTS:
%   vol - 3D volume
%   target_range - array of two numbers, for example [0 1], or [0 255]
%   OUTPUTS: 
%   vol_scaled - the scaled volume
%   minmax - values of the original values that can be used to restore the
%   original scaling


[max_FV,~]=max(vol,[],3);
[min_FV,~]=min(vol,[],3); 
vol_scaled=(vol-min_FV)./(max_FV-min_FV);

end