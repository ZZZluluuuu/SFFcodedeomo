function fun_MergeImg(RootPath,rows,cols,HEdge,VEdge,ScaleImage,path)
    AllPath = cell(rows,cols);
    for i = 0:rows-1
        for j = 0:cols-1
            AllPath{i+1,j+1} = [RootPath,num2str(i,'%03d'),num2str(j,'%03d'),'.jpg'];
        end
    end

    [h,w,~] = size(imread(AllPath{1,1}));

    VPreV = [VEdge:-1:1]'/(VEdge+1);
    VNextV = [1:VEdge]'/(VEdge+1);

    HPreV = [HEdge:-1:1]/(HEdge+1);
    HNextV = [1:HEdge]/(HEdge+1);
    %% 
    for j = 0:cols-1        
        for i = 0:rows-1
            if i==0
                FullFileName = AllPath{i+1,j+1};
                TempI = im2double(imread(FullFileName));
                VFullFileName = AllPath{i+2,j+1};
                VTempI = im2double(imread(VFullFileName));
                VMergeImage(1:h-VEdge,1:w,:) = TempI(1:h-VEdge,1:w,:);
                VMergeImage(h-VEdge+1:h,1:w,:) = VPreV.*TempI(h-VEdge+1:h,1:w,:)+VNextV.*VTempI(1:VEdge,1:w,:);
            elseif i>0&&i<rows-1
                FullFileName = AllPath{i+1,j+1};
                TempI = im2double(imread(FullFileName));
                VFullFileName = AllPath{i+2,j+1};
                VTempI = im2double(imread(VFullFileName));
                VMergeImage(i*h-(i-1)*VEdge+1:(i+1)*(h-VEdge),1:w,:) = TempI(VEdge+1:h-VEdge,1:w,:);
                VMergeImage((i+1)*(h-VEdge)+1:(i+1)*h-i*VEdge,1:w,:) = VPreV.*TempI(h-VEdge+1:h,1:w,:)+VNextV.*VTempI(1:VEdge,1:w,:);
            else
                FullFileName = AllPath{i+1,j+1};
                TempI = im2double(imread(FullFileName));
                VMergeImage((rows-1)*h-(rows-2)*VEdge+1:rows*h-(rows-1)*VEdge,1:w,:) = TempI(VEdge+1:h,1:w,:);
            end
        end
        [H,W,~] = size(VMergeImage);
        if j==0
            MergeImage(1:H,1:W-HEdge,:) = VMergeImage(1:H,1:W-HEdge,:);
            MergeImage(1:H,W-HEdge+1:W,:) = HPreV.*VMergeImage(1:H,W-HEdge+1:W,:);
        elseif j>0&&j<cols-1
            MergeImage(1:H,j*(W-HEdge)+1:j*(W-HEdge)+HEdge,:) = MergeImage(1:H,j*(W-HEdge)+1:j*(W-HEdge)+HEdge,:)+HNextV.*VMergeImage(1:H,1:HEdge,:);
            MergeImage(1:H,j*W-(j-1)*HEdge+1:(j+1)*(W-HEdge),:) = VMergeImage(1:H,HEdge+1:W-HEdge,:);
            MergeImage(1:H,(j+1)*(W-HEdge)+1:(j+1)*(W-HEdge)+HEdge,:) = HPreV.*VMergeImage(1:H,W-HEdge+1:W,:);
        else
            MergeImage(1:H,j*(W-HEdge)+1:j*(W-HEdge)+HEdge,:) = MergeImage(1:H,j*(W-HEdge)+1:j*(W-HEdge)+HEdge,:)+HNextV.*VMergeImage(1:H,1:HEdge,:);
            MergeImage(1:H,j*W-(j-1)*HEdge+1:(j+1)*(W-HEdge)+HEdge,:) = VMergeImage(1:H,HEdge+1:W,:);
        end

    end
    MergeImage = imresize(MergeImage,ScaleImage);
    imwrite(MergeImage,[path,'\MergeImage.jpg']);
end